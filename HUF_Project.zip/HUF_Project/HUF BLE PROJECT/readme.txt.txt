PORT SETUP : https://www.bleuio.com/getting_started/docs/intro/

HOW TO CONNECT DONGLE IN WINDOWS, MAC , RASPEBERRY : https://www.bleuio.com/getting_started/docs/howtouse/

UPDATE FIRMWARE : https://www.bleuio.com/getting_started/docs/firmware/

Instalar biblioteca : npm i bleuio
Importar biblioteca : import * as my_dongle from 'bleuio'

Instalar Parcel : https://parceljs.org/getting-started/webapp/

1º -> Abrir pasta Ver_Macs para usar a aplicação do fabricante para ver quais os MAC'S de cada beacon.
Comando para Executar : npx parcel index.html

2 -> Abrir 'Base de dados' do administrador. Como envolve PHP é necessário aplicação por exemplo XAMP. Usei o XAMP e é possível rodar o programa através do comando :
 start /B C:\Xamp\php\php.exe -S localhost:8000
Fazer o CRUD consoante o necessário, salvar dados. Clicar no botão "SEND TO MQTT" para enviar os dados para o tópico File do MQTT. 

3-> Abrir aplicação Cliente. Comando : npx parcel index.html
indicar qual o nome da linha em que estamos e o ID de maquina, clicar em 'send' para validar dados. Introduzir o intervalo em segundos e o numero de resultados para fazer média , e iniciar Scan. Os resultados são registados e enviados para o tópico 'Linha/ID'.

4 -> Abrir interface admin. É necessário abrir o "Localhost:3000" ( ou qualquer outra porta) antes de iniciar o "npm start" porque como não há base de dados então os dados estão apenas guardados durante a execução do servidor.



